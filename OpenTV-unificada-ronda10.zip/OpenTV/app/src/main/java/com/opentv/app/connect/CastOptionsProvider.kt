package com.opentv.app.connect

import android.content.Context
import com.google.android.gms.cast.CastMediaControlIntent
import com.google.android.gms.cast.framework.CastOptions
import com.google.android.gms.cast.framework.OptionsProvider
import com.google.android.gms.cast.framework.SessionProvider

/**
 * Configuración del SDK de Cast, referenciada por nombre desde el AndroidManifest
 * (`OPTIONS_PROVIDER_CLASS_NAME`). Usa el receptor multimedia predeterminado de Google, que
 * reproduce enlaces directos de video y audio sin necesidad de registrar una app receptora propia.
 */
class CastOptionsProvider : OptionsProvider {

    override fun getCastOptions(context: Context): CastOptions =
        CastOptions.Builder()
            .setReceiverApplicationId(CastMediaControlIntent.DEFAULT_MEDIA_RECEIVER_APPLICATION_ID)
            .build()

    override fun getAdditionalSessionProviders(context: Context): List<SessionProvider>? = null
}
