# Registro de avances

## Fase 1: proyecto base

### Archivos creados
- Gradle: `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`,
  `gradle/libs.versions.toml`, `app/build.gradle.kts`, `app/proguard-rules.pro`,
  `gradlew`, `gradlew.bat`, `gradle/wrapper/*` (Gradle 8.9), `.gitignore`.
- Android: `AndroidManifest.xml`, `res/values` (strings, colors, themes),
  `res/drawable` (`ic_launcher`, `banner`).
- Kotlin (`com.opentv.app`): `MainActivity`, `core/AspectRatio`, `device/DeviceInfo`,
  `navigation/{Routes,OpenTvNavHost}`, `ui/theme/*`, `ui/components/*`,
  `ui/home/*`, `ui/device/DeviceInfoScreen`, `ui/pending/PendingScreen`, `ui/settings/SettingsScreen`.
- Pruebas: `AspectRatioTest` (5), `RoutesTest` (4).

### Versiones elegidas (SIN verificar contra los repositorios)
AGP 8.5.2 · Kotlin 1.9.24 · Compose compiler 1.5.14 · Compose BOM 2024.06.00 · Activity 1.9.1 ·
Navigation 2.7.7 · Lifecycle 2.8.4 · Coroutines 1.8.1 · Gradle 8.9.
Combinación elegida por compatibilidad conocida (Kotlin 1.9.24 ↔ compilador Compose 1.5.14).
No se pudo resolver ninguna desde este entorno.

### Verificación real
| Qué | Resultado |
|---|---|
| Pruebas JUnit de `AspectRatio` y `Routes` (9) | **Pasan**, compiladas con Kotlin 2.0.21 (el del Gradle local) y ejecutadas con JUnit 4.13.2 en la JVM. No es la toolchain del proyecto (Kotlin 1.9.24). |
| Todos los XML (manifest, recursos) | Bien formados. |
| `./gradlew assembleDebug` | **NO ejecutado.** El entorno no tiene Android SDK y el proxy bloquea `dl.google.com`, `maven.google.com`, Maven Central y el Gradle Plugin Portal (403). |
| Código Compose/Android (UI, MainActivity, DeviceInfo) | **NO compilado ni probado.** Escrito con cuidado, pero puede tener errores de compilación. |
| Pruebas en teléfono o TV | **Ninguna.** No hay dispositivo físico. |
| APK | **No generado.** |

### Errores / riesgos pendientes
1. Primer `assembleDebug` puede revelar errores de compilación o de versiones: corregir y repetir.
2. Foco inicial con `LaunchedEffect` + `requestFocus()`: comprobar en dispositivo que no falle al
   abrir con teclado, mando y toque.
3. Comprobar en un TV/pantalla externa que el margen del 5 % y la muesca se ven bien.
4. Comprobar que el ícono vectorial del launcher se ve correcto en teléfonos con Android 7.

### Pasos exactos para continuar
1. En una máquina con Android SDK y red: `./gradlew :app:testDebugUnitTest :app:assembleDebug`.
2. Pegar aquí cualquier error de Gradle; se corrige antes de pasar de fase.
3. Instalar el APK y probar con teclado/mando: flechas, Enter, Escape.
4. Fase 2 (Launcher): apps instaladas con `<queries>` para `ACTION_MAIN`/`LAUNCHER`, búsqueda,
   favoritos, categoría `HOME` y apertura con `ActivityOptions`.


---

## Fase 2: launcher

### Archivos nuevos o modificados
- Datos: `apps/{InstalledApp,AppsRepository,FavoritesStore,AppLauncher,AppLaunchController,
  AppListLogic,AppIconLoader,AppsViewModel}`, `core/OrientationPolicy`, `AppContainer`, `OpenTvApp`.
- Launcher: `launcher/DefaultLauncherHelper`.
- UI: `ui/apps/{AppsScreen,AppTile,LaunchFeedback}`, `ui/components/SearchField`,
  `ui/components/FocusableSurface` (pulsación prolongada), `ui/components/TvComponents`
  (`horizontalPadding`), `ui/home/{HomeScreen,HomeViewModel}` (fila «Tus favoritas»),
  `ui/settings/SettingsScreen` (launcher predeterminado), `navigation/*`, `MainActivity`.
- Manifest: `<queries>` (LAUNCHER, LEANBACK_LAUNCHER, HOME), `OpenTvApp`, `launchMode=singleTask`,
  alias `.HomeAlias` con categoría HOME. Sin permisos nuevos.
- Compilación: `.github/workflows/build.yml` (GitHub Actions, para quien no tiene computadora).
- Pruebas: `AppListLogicTest`, `AppLaunchControllerTest`, `OrientationPolicyTest`.

### Incidente de la sesión (corregido)
Esta fase ya estaba escrita cuando se retomó. Se sobrescribieron por error 5 archivos con otra
versión y se crearon 4 duplicados. Se resolvió conservando el diseño original: se borraron los
duplicados y se reescribieron los 5 archivos para que coincidan con sus consumidores. Después se
verificó que no queden imports sin declaración ni tipos duplicados.

### Verificación real
| Qué | Resultado |
|---|---|
| Pruebas de lógica pura (27: aspecto, rutas, orientación, búsqueda/orden, controlador de apertura) | **Pasan** en la JVM, con Kotlin 2.0.21 (no el 1.9.24 del proyecto). |
| Imports internos, tipos duplicados, símbolos eliminados | **Auditados con script**: sin problemas. |
| XML del manifest y recursos, YAML del workflow | Válidos. |
| Compilación Gradle, UI Compose, `PackageManager`, alias HOME | **NO ejecutados.** Sin Android SDK ni red a Google/Maven en el entorno. |
| Workflow de GitHub Actions | **No ejecutado.** |
| Pruebas en teléfono o TV | **Ninguna.** |
| APK | **No generado.** |

Los fallos al abrir apps (no encontrada, denegada, error) se prueban con un doble del lanzador; el
`AppLauncher` real que llama a Android no tiene prueba.

### Riesgos conocidos
1. **Pulsación prolongada con mando**: `combinedClickable` puede no detectar mantener OK en un
   D-pad. Las teclas Menú y F siempre funcionan; en táctil la pulsación prolongada sí.
   Si en un mando no hay Menú, hay que añadir un botón visible de favorita.
2. **Foco inicial** en la grilla: usa un cuadro de espera + `requestFocus` dentro de `runCatching`;
   si falla, no hay foco inicial (no se cierra la app), pero hay que comprobarlo en dispositivo.
3. **Botón Inicio como launcher**: depende de `singleTask` + intent nuevo; comprobar que vuelve
   al inicio desde una subpantalla.
4. Algunos fabricantes ocultan `ACTION_HOME_SETTINGS`: la app lo detecta y muestra instrucciones.
5. Cualquier error de compilación de Gradle (versiones de dependencias sin verificar).

### Pasos exactos para continuar
1. Subir el proyecto a GitHub y mirar el resultado de la pestaña Actions (ver README).
2. Pegar el primer error de compilación para corregirlo.
3. Instalar el APK y probar: abrir apps, buscar, marcar favoritas, apps solo verticales, elegir
   OpenTV como launcher y volver al original.
4. Fase 3: conectividad (Miracast vía ajustes del sistema, Cast, DLNA) y pantalla «Conectar TV».


---

## Fase 3: conectividad (Conectar TV)

### Archivos
- `connect/`: `Capabilities` (estados y evaluador), `MirroringGuide`, `Troubleshooting`, `Ssdp`,
  `SsdpSearch` (UDP), `UpnpDescription`, `HttpMessages`, `LanHttp` (socket), `LanAddress` (política
  de red local), `DlnaSoap`, `DlnaController`, `SystemCastLauncher`, `ExternalDisplayMonitor`,
  `CapabilityDetector`, `CastDiscovery`, `CastOptionsProvider`, `ConnectViewModel`.
- UI: `ui/connect/ConnectTvScreen`; cambios en `HomeScreen`/`HomeViewModel` (chip real de pantalla
  externa), `DeviceInfoScreen`, `Routes` (+`CONNECT`, −`PendingFeature.CONNECT_TV`), `OpenTvNavHost`,
  `AppContainer`, `Color` (+`Success`).
- Manifest: permisos `INTERNET` y `ACCESS_NETWORK_STATE`, `<queries>` de `CAST_SETTINGS`, meta-data
  del SDK de Cast. Gradle: `play-services-cast-framework` 21.4.0 y `androidx.mediarouter` 1.6.0.
- Pruebas nuevas: `CapabilityEvaluatorTest`, `MirroringGuideTest`, `SsdpTest`, `UpnpDescriptionTest`,
  `HttpMessagesTest`, `LanAddressTest`, `DlnaSoapTest`, `DlnaControllerTest`, `SocketLanHttpTest`,
  `TroubleshootingTest`.

### Decisiones y desvíos respecto del pedido
- **Miracast sin conexión desde la app**: no existe API pública para escanear ni conectar. Se
  detecta la pantalla externa y se abre el ajuste del sistema; no se inventa nada más.
- **Cast solo detecta** (el envío usa el reproductor, Fase 4). **Wi‑Fi Direct solo detecta**
  (el canal real entre teléfonos es de la Fase 5). Ambos figuran así en pantalla.
- **DLNA con sockets propios**, sin `usesCleartextTraffic`: solo IPv4 privadas, el `LOCATION` debe
  venir del mismo equipo que respondió, XML sin DOCTYPE/ENTITY, respuestas con tope de tamaño y tiempo.

### Incidente de la sesión (corregido)
Había una capa pura de Fase 3 ya escrita. Se crearon por error archivos paralelos que chocaban con
ella; se borraron y se adoptó el diseño existente. Tres pruebas propias tenían expectativas mal
escritas y se corrigieron (texto de mensaje, carácter inválido en XML 1.0, una tilde).

### Verificación real
| Qué | Resultado |
|---|---|
| 94 pruebas de lógica pura (incluye SSDP, UPnP, SOAP, controlador DLNA con dobles y socket real por loopback) | **Pasan** en la JVM con Kotlin 2.0.21 (no el 1.9.24 del proyecto). |
| Imports internos, tipos duplicados, miembros de `AppContainer` usados | **Auditados con script**: sin problemas. |
| XML del manifest | Válido. |
| Compilación Gradle de la capa Android, Compose, SDK de Cast, versiones 21.4.0/1.6.0 | **NO ejecutado.** Sin Android SDK ni acceso a Google/Maven en el entorno. |
| Búsqueda SSDP/DLNA contra un TV real, Cast real, pantalla externa real | **Ninguna prueba en hardware.** |
| Workflow de GitHub Actions | **No ejecutado.** |

### Riesgos conocidos
1. Versiones del SDK de Cast y mediarouter sin verificar; si Gradle no las resuelve, ajustar.
2. SSDP: algunos routers/teléfonos filtran multicast; las respuestas son unicast y no se usa
   `MulticastLock`. Si en un equipo no aparece ningún TV con DLNA activo, probar a agregarlo.
3. `isOnLocalNetwork` mira solo la red activa: un Wi‑Fi sin internet puede figurar como «sin red».
4. Varios TV DLNA exigen metadatos DIDL‑Lite o tipos MIME concretos; hoy se envía el enlace sin
   metadatos y el TV puede rechazarlo (el mensaje del TV se muestra tal cual).
5. El foco con mando en la pantalla larga y el botón «Desconectar» solo se verifican en dispositivo.

### Pasos exactos para continuar
1. Subir a GitHub y mirar Actions; pegar el primer error de compilación.
2. En un teléfono: abrir «Conectar TV», comprobar estados, abrir la transmisión del sistema, buscar
   TV por DLNA y enviar un enlace de prueba de tu red local.
3. Fase 4: reproductor Media3, selector de documentos, envío por Cast y servir archivos locales por DLNA.


---

## Fase 4 (en curso)

### Módulo 1: reproductor Media3
- `player/{PlayableUrl,VideoFit,PlayerViewModel}`, `ui/player/PlayerScreen`; ruta `PLAYER` real (sale de `PendingFeature`).
- Dependencias: Media3 1.4.1 (exoplayer, hls, dash, ui), sin verificar contra el repositorio.
- Manifest: `usesCleartextTraffic="true"` (para enlaces http de la red local). Es una decisión de seguridad a revisar.
- Verificado: 101 pruebas de lógica pura (7 nuevas). NO verificado: compilación, reproducción real, `PlayerView` con el tema Material del sistema.

### Módulo 2: pantalla externa y envío directo
- `connect/{CastSender,CastMime}`: toque en un dispositivo Cast → `MediaRouter.selectRoute` → sesión → `RemoteMediaClient.load` con el enlace. «Desconectar Cast» cierra la sesión.
- `ui/player/ExternalPresentation`: con pantalla externa, «Ver en la pantalla externa» dibuja el video en una `Presentation` a la resolución nativa del TV; el celular queda como control (Pausar/Reanudar).
- Enlace compartido entre reproductor y «Conectar TV» (`AppContainer.sharedLink`); botón «Enviar a un TV» en el reproductor.
- Verificado: 103 pruebas de lógica pura. NO verificado: compilación, API de Cast (`SessionManagerListener`, `selectRoute`), `Presentation` en el Redmi 14C, reproducción en un TV real.
- Límites: Cast necesita que el receptor pueda abrir el enlace (CORS en HLS/DASH, enlaces vencidos); la `Presentation` solo funciona si Android informa una pantalla externa y puede reemplazar al espejo del sistema, algo que solo se comprueba en el equipo.

### Módulo 2 (rehecho): selector de TV propio
Corrige un reclamo real: las tarjetas eran texto y no había ícono ni selector.
- `ui/connect/CastIcon` (ícono dibujado a mano + `CastButton`), `ui/connect/CastPickerDialog` (lista unificada de TV Cast y DLNA; al tocar uno envía el enlace desde OpenTV; botones «Buscar de nuevo» y «Detener / desconectar»).
- El botón de Cast está en el inicio, en el reproductor y en «Conectar TV». Las tarjetas de Cast/DLNA/Miracast de «Conectar TV» son clicables.
- `connect/TvTargets`, `CastDevice` (archivo propio), `ConnectViewModel.send/stopAll`, `core/BuildInfo` (etiqueta «Fase 4 · módulo 2 (selector de Cast propio)» visible en el inicio y en «Dispositivo»).
- Verificado: 106 pruebas de lógica pura; imports auditados. NO verificado: compilación, el diálogo con D-pad/táctil, Cast y DLNA contra un TV real, `Presentation` en el Redmi 14C.
- Miracast: sigue pasando por el ajuste del sistema; no existe API pública para conectarlo desde una app.

### Módulo 3A: TV elegido y launcher en filas
- Tocar un TV (Cast o DLNA) en el selector lo elige como salida: con Cast abre la sesión en el momento (`CastSender.connect`); con DLNA queda como destino. `connect/OutputController`.
- Con un TV elegido, «Reproducir» envía el enlace allí (botones «Detener en el TV» / «Ver aquí en el celular»).
- Se quitó la caja de enlace del selector y de «Conectar TV». La entrada manual de enlaces quedó en Configuración › Herramientas (`ui/settings/ToolsScreen`); el reproductor ya no está en el inicio.
- Inicio en filas horizontales (`LazyRow`): Aplicaciones (favoritas primero + «Ver todas»), Multimedia, Ajustes.
- Etiqueta de versión: «Fase 4 · módulo 3A».
- Verificado: pruebas de lógica pura e imports. NO verificado: compilación, Cast/DLNA contra el LG, foco con D-pad en las filas.
- PENDIENTE (módulo 3B): proyectar el launcher en la pantalla externa con `Presentation` y control remoto desde el celular. Límite conocido: las apps de terceros se abren en la pantalla del teléfono, no en el TV.

### Módulo 3B: proyección inalámbrica propia 16:9 y fila de apps con «+»
Pilar fijado por el usuario: nada de HDMI/MHL ni «Emitir» del sistema; todo por Wi‑Fi y propio de OpenTV.
- Fila «Aplicaciones» del inicio: solo las favoritas fijadas + tarjeta «+» (`ui/apps/AppPickerDialog`) para agregar/quitar. «Todas las apps» pasó a la fila Ajustes.
- Proyección (`stream/`): pantalla virtual propia de 1920×1080 (`DisplayManager.createVirtualDisplay`, sin MediaProjection) donde se dibuja la interfaz del TV (`ui/remote/TvPresentation` + `TvLauncherContent`) → `ScreenEncoder` (MediaCodec H.264, repite cuadro si no hay cambios) → `TsMuxer` (MPEG-TS propio) → `StreamHub` + `HttpStreamServer` (solo IPv4 privadas, ruta con código aleatorio, máx. 2 clientes) → DLNA `SetAVTransportURI` con metadatos DIDL-Lite (`DidlLite`) y `Play`. Orquesta `TvProjection`.
- Control remoto táctil (`ui/remote/RemoteScreen`, `RemoteViewModel`, `stream/TvNavigation`): cruceta, OK e Inicio mueven el cursor de la interfaz que se ve en el TV.
- DIDL-Lite también se envía ahora con cualquier enlace DLNA (muchos LG lo exigen).
- Verificado en la JVM: 129 pruebas (TsMuxer: ida y vuelta del video para 13 tamaños, CRC de PAT/PMT, contadores, PCR, PTS; servidor HTTP por loopback; hub; navegación; DIDL). NO verificado: compilación; MediaCodec, pantalla virtual y `Presentation` en el Redmi 14C; que el LG 42LB5800 (NetCast) acepte un MPEG-TS en vivo por DLNA; retraso real; Compose dentro de la `Presentation`.
- Límites: retraso de varios segundos (búfer del TV); sin audio; solo DLNA (no Cast); las apps de terceros se abren en el teléfono; si OpenTV pasa a segundo plano la imagen del TV puede congelarse (falta un servicio en primer plano).

### Módulo 3C: compatibilidad con TV viejos y pantalla negra
Reporte real: LG 42LB5800 (NetCast) dijo «Archivo no compatible»; un TV Linux de 32" aceptó pero quedó en negro.
- Causa probable LG: se anunciaba `MPEG_TS_HD_NA_ISO` (perfil MPEG-2) con video H.264, y el TS no tenía audio. Ahora: perfil `AVC_TS_HD_NA_ISO`, pista de audio AAC muda (`SilentAudioEncoder`, `Adts`, `TsMuxer(withAudio)`), H.264 Main nivel 4.0 (3.1 en 720p) a bitrate constante, `Accept-Ranges: none`, `realTimeInfo`.
- Causa probable pantalla negra: el codificador solo recibía cuadros si la ventana de la pantalla virtual dibujaba; si no dibujaba, no salía nada. Ahora `ViewFrameFeeder` dibuja la interfaz directo sobre el codificador a 15 cuadros/s (o un cartel «OpenTV» si la interfaz no está visible). La pantalla virtual solo aloja la ventana (su imagen se descarta en un `ImageReader`).
- 5 formatos seleccionables en la app (`StreamProfile`, botón «Cambiar formato»): H.264 con perfil DLNA, TS genérico, MIME `video/vnd.dlna.mpeg-tts`, sin metadatos DIDL, 720p.
- Diagnóstico en pantalla (`ProjectionStats`): cuadros dibujados/codificados, bytes enviados, conexiones y último pedido del TV (método + user-agent), si la interfaz se ve, y una pista de dónde está el corte.
- El TV pide un fotograma clave al conectarse (`StreamHub.onSubscribe`).
- Verificado en la JVM: 143 pruebas (audio TS ida y vuelta, PMT con/sin audio y CRC, ADTS, perfiles, cabeceras HTTP por perfil, registro del pedido, estadísticas). NO verificado: compilación; MediaCodec AAC/H.264; dibujar la vista Compose con `lockHardwareCanvas`; que cualquiera de los 5 formatos lo acepte el LG o el TV de 32".

### Módulo 3C-2: corte al segundo de reproducción
Reporte real: ambos TV abren el formato (sin error) y muestran la interfaz, pero tras ~1 s salen de la reproducción, en los 5 formatos.
- Causa probable (hipótesis, no confirmada): con la interfaz quieta el codificador casi no entrega datos (unos kbps + audio mudo); el TV vacía su búfer y abandona. Corrección: relleno con paquetes nulos TS (`TsPadding`, PID 0x1FFF) hasta un caudal mínimo constante de 2 Mbps, emitido por un hilo (`TvProjection.startPadder`).
- El dibujo ya no se detiene ante un error (`ViewFrameFeeder` cuenta errores y reintenta); el codificador repite el último cuadro si se frena el dibujo; TCP_NODELAY y búfer de envío de 256 KB.
- Diagnóstico nuevo en el teléfono: cómo terminó la última conexión («el TV cerró…» u «OpenTV detuvo…», con segundos y KB), errores al dibujar y su texto.
- Verificado en la JVM: 146 pruebas (relleno nulo válido, cálculo de relleno, contador del hub). NO verificado: compilación y que el relleno corrija el corte.
- Pendiente probable: servicio en primer plano (si Android pone la app en segundo plano al cambiar de pantalla, el dibujo se frena).

### Módulo 3C-3: servicio en primer plano e historial de red
Reporte real: el relleno a 2 Mbps no cambió nada; sigue 1 s de imagen y salida del TV en ambos televisores y todos los formatos. La hipótesis del caudal queda debilitada (no descartada: no se vio el bloque de estado).
- `stream/ProjectionService`: servicio en primer plano (tipo `mediaPlayback`, permisos normales `FOREGROUND_SERVICE` y `FOREGROUND_SERVICE_MEDIA_PLAYBACK`) que vive mientras dura la proyección; lo inicia y detiene `TvProjection`.
- `HttpStreamServer.history`: últimos 10 eventos con tiempo (conexión, pedido, cierre y quién cortó); se muestra en el estado de la pantalla de proyección.
- Verificado en la JVM: 147 pruebas. NO verificado: compilación, el servicio en el Redmi 14C ni la causa del corte.

### Módulo 3C-4: diagnóstico siempre visible y prueba aislada
Reporte real: con el 3C-3 el bloque de estado no mostró nada. Causas halladas: el bloque solo se dibujaba en el estado «proyectando» y la etiqueta de versión no se había actualizado desde el 3C (no había forma de confirmar el APK instalado). Revisado: nada dentro de la app detiene la proyección por su cuenta (solo el botón, OK en la fila «Detener» o cerrar la app).
- El bloque de estado se ve siempre que haya datos, también después de detenerse o fallar, con la versión instalada, la fase, el historial combinado de la app (inicio, pantalla virtual, envío al TV, respuesta del TV, quién detiene) y de la red (conexión, pedido, cierre) ordenado por tiempo, y un botón «Copiar diagnóstico».
- «Prueba sin interfaz»: envía una barra que se mueve y un contador en lugar de la interfaz de OpenTV. Si el TV también corta, el problema no está en dibujar la interfaz.
- Etiqueta: «módulo 3C-4 (diagnóstico siempre visible)».
- Verificado en la JVM: 148 pruebas. NO verificado: compilación ni la causa del corte.

### Módulo 3C-5: el corte lo causaba OpenTV (causa confirmada con datos)
Registro real en la LG NetCast: el TV hizo GET del video y leyó más de 500 KB, pero ~2 s después el comando `Play` terminó en «Unreachable» (el TV no contesta el SOAP mientras abre el flujo) y OpenTV, al tomarlo como fallo, se detuvo a sí mismo. Las hipótesis anteriores (caudal, cierre del socket, segundo plano) no eran la causa; el relleno nulo y el servicio en primer plano quedan, son inofensivos.
- `stream/PlayOutcome`: si el TV no confirma el Play pero ya descarga el video, se sigue transmitiendo; solo se corta si no confirma Y no pide el video (con 4 s de gracia).
- Etiqueta: «módulo 3C-5 (Play tolerante)».
- Verificado en la JVM: 151 pruebas. NO verificado: compilación, y que la LG sostenga la reproducción después de esto; la TV de 32" no mandó registro.

### Módulo 3D: latencia y verificación de 1920×1080
Confirmado en la LG NetCast: con el Play tolerante (3C-5) la transmisión es continua y estable; la interfaz responde al control remoto. Queda el retraso entre pulsar y ver el cambio.
- `stream/StreamLatency` (botón «Latencia» en la pantalla de proyección): «Estable» (lo probado) y «Baja latencia» (30 cuadros/s, márgenes de tiempo del flujo reducidos: PTS +0,2 s y PCR 0,1 s antes en lugar de 0,7/0,5 s, caudal mínimo 4 Mbps, `latency`/`priority` del codificador). `TsMuxer` recibe los márgenes por parámetro (valores por defecto sin cambios).
- El piso del retraso es el búfer interno del TV: no se controla desde la app. El GOP ya era de 1 s; `KEY_INTRA_REFRESH` no se usó porque el retraso no viene de los fotogramas clave.
- El lienzo ya es exactamente 1920×1080 (pantalla virtual, ventana y codificador); la «Prueba sin interfaz» ahora dibuja un marco naranja en los 4 bordes y «1920×1080» para ver en el TV si recorta o deja franjas (overscan/zoom del propio TV).
- Etiqueta: «módulo 3D (latencia + marco de prueba)». Verificado en la JVM: 153 pruebas. NO verificado: compilación, cuánto baja el retraso real, ni que el modo de baja latencia lo acepte la LG.
- Espejo del teléfono (MediaProjection + Shizuku/`wm size`): diseñado, no implementado (ver mensaje al usuario).

### Módulo 3E: espejo de pantalla y latencia por partes
Reporte real (módulo 3D): «Estable» ~3–4 s de retraso; «Baja latencia» (30 fps + 4 Mbps + márgenes cortos, todo junto) empeoró a ~5–6 s. Como se cambiaron varias cosas a la vez, no se sabe cuál empeoró.
- Latencia (`stream/StreamLatency`): se eliminó «Baja latencia». Ahora 3 variantes, cada una cambia UNA cosa respecto de «Estable»: «Cola corta, sin relleno» (sin paquetes nulos, búfer de envío del socket 32 KB, cola máxima 192 KB por cliente), «Margen de tiempo corto» (PTS/PCR más cercanos). 15 fps en todas.
- `StreamHub`: cola acotada también por bytes; si el TV se atrasa se descarta lo viejo y se retoma en el próximo fotograma clave (el retraso no crece; la imagen puede saltar). `HttpStreamServer`: tamaño del búfer de envío configurable.
- No se tocó el GOP (1 s): `KEY_I_FRAME_INTERVAL` es entero en segundos y 0 significa todo fotogramas clave (mucho más caudal). El empaquetado TS agrega ~4 % de cabeceras: no es fuente de retraso.
- Espejo (`TvProjection.start(..., mirror = MirrorRequest)`): MediaProjection (permiso del sistema en cada sesión) → pantalla virtual `AUTO_MIRROR` de 1920×1080 directo al codificador → misma tubería DLNA. El sistema encaja la pantalla sin deformarla (franjas si la proporción no es 16:9). `ProjectionService` declara además el tipo `mediaProjection`, espera estar en primer plano antes de capturar (requisito de Android 14), registra el callback antes de crear la pantalla virtual y su notificación tiene el botón «Detener». Apps con DRM salen negras.
- NO implementado a propósito: `wm size` vía Shizuku/ADB. Desde este entorno no se puede verificar la librería de Shizuku (Maven Central bloqueado) ni su API actual; agregarla a ciegas puede romper la compilación de todo. Queda para un módulo aparte.
- Etiqueta: «módulo 3E (espejo + latencia por partes)». Verificado en la JVM: 156 pruebas (cola por bytes, variantes de latencia). NO verificado: compilación, MediaProjection ni el servicio en Android 14 en el Redmi 14C, ni cuánto baja el retraso.

### Módulo 3F: 16:9 forzado con Shizuku y restauración
Reporte real (3E): espejo por MediaProjection estable en la LG; con el teléfono 20:9 aparecen franjas; el retraso por el búfer del TV sigue.
- `display/ScreenResizer` (lógica pura, 9 pruebas): lee `wm size`/`wm density`, calcula 16:9 vertical (720×1640 → 1080×1920 y densidad 320 → 480 para conservar el ancho en dp), guarda en disco QUÉ restaurar ANTES de cambiar (`PrefsResizeStore`, `commit()` síncrono), verifica el cambio y lo revierte si el sistema no lo aceptó, restaura el override previo del usuario si lo había, y no pisa lo guardado si se aplica dos veces. Solo permite comandos `wm size|density` (`isAllowedCommand`).
- `display/ShizukuShell` + `ShellUserService` + `IUserService.aidl`: servicio que Shizuku ejecuta con permisos de shell (patrón UserService de Shizuku). Estado: no instalada / no activa / versión vieja / falta permiso / lista.
- Se aplica al espejar si «16:9 forzado» está en Sí; se restaura al detener (botón, botón «Detener y restaurar» de la notificación, error de arranque) y al abrir la app si quedó pendiente. Botón «Restaurar resolución» en la pantalla.
- Latencia: el modo por defecto pasó a «Cola corta, sin relleno» con búfer de envío de 16 KB (descarta lo viejo si el TV se atrasa). No hay datos de cuál variante fue mejor.
- Dependencias nuevas SIN verificar (Maven Central bloqueado desde el entorno): `dev.rikka.shizuku:api` y `provider` 13.1.5; `aidl = true`; proveedor `rikka.shizuku.ShizukuProvider` en el manifiesto. Reglas de R8 agregadas.
- Etiqueta: «módulo 3F (Shizuku 16:9 + restauración)». Verificado en la JVM: 165 pruebas. NO verificado: compilación (las llamadas a la API de Shizuku están escritas según su patrón documentado, de memoria), el servicio con permisos de shell, que `wm size` surta efecto en el Redmi 14C, ni la restauración real.

### Módulo 3G: espejo nativo (Miracast del sistema) con 16:9 forzado por Shizuku
Reporte real (3F): con Shizuku activa y conectada, «16:9 forzado» no cambiaba nada. Causa: ese botón solo marcaba una opción que se aplicaba al arrancar el espejo propio por DLNA (MediaProjection); nunca se conectó con el espejo nativo, y «Restaurar» decía «nada que restaurar» porque nunca se había aplicado. Error de diseño mío.
Decisión del usuario: dejar DLNA y usar el espejo nativo del sistema (Miracast / pantalla inalámbrica).
- `display/NativeMirrorFlow` (lógica pura, 6 pruebas con teléfono simulado): 1) fuerza 16:9 con `ScreenResizer` (OBLIGATORIO: si falla, NO se abre el panel de transmisión y se muestra el motivo); 2) abre la transmisión del sistema (`SystemCastLauncher`); 3) vigila la pantalla externa (`ExternalDisplayMonitor`): al desconectarse restaura; si no se conecta en 3 minutos restaura; si el teléfono no tiene panel de transmisión restaura. Corre en un alcance propio de la app (sigue vigilando con OpenTV en segundo plano).
- Pantalla «Espejo nativo 16:9» (`ui/mirror`, ruta `mirror`, tarjeta en el inicio): estado de Shizuku, permiso, botón «Forzar 16:9 y abrir transmisión», «Detener y restaurar», «Restaurar resolución» y la etiqueta de versión.
- En la pantalla del espejo propio el botón se renombró «16:9 en espejo propio» para no confundir.
- Etiqueta: «módulo 3G (espejo nativo + Shizuku)». Verificado en la JVM: 171 pruebas. NO verificado: compilación; que `ShizukuShell.exec` ejecute realmente `wm size`/`wm density` (nunca se probó el servicio con permisos de shell: es la primera prueba real); que Miracast acepte el cambio de resolución sin cortarse; el cierre de la app con la resolución forzada.
- Límite: si el proceso muere con el panel de transmisión abierto, la restauración ocurre al abrir OpenTV de nuevo (o con el botón / Termux).

### Módulo 3G-2: Shizuku por vía directa
Reporte real (3G): Shizuku «lista», pero al forzar 16:9: «Timed out waiting for 8000 ms». Era el `withTimeout` de `ShizukuShell.connect()`: el servicio auxiliar (`ShellUserService`) nunca llamó a `onServiceConnected`; el comando `wm` ni se ejecutó. Causa de fondo NO confirmada (sin registros del proceso auxiliar).
- `ShizukuShell.exec` ahora prueba primero la vía directa (`Shizuku.newProcess` por reflexión: `sh -c` con permisos de shell, sin proceso auxiliar; timeout 6 s) y, si falla, el servicio auxiliar (timeout 4 s). Si ambas fallan, el error lista cada motivo («directo: … | servicio auxiliar: …»). El timeout de coroutines se trata como error, no como cancelación. La lista blanca de comandos (`wm size|density`) se exige también en la app.
- Etiqueta: «módulo 3G-2 (Shizuku por vía directa)». Verificado en la JVM: 171 pruebas (la lógica no cambió). NO verificado: compilación; que `newProcess` exista con esa firma en la API 13.1.5 (privado, firma tomada de memoria); que funcione en el Redmi 14C.

### Módulo 3G-3: 16:9 persistente (causa del reinicio a los 2 s)
Reporte real (3G-2): Shizuku funciona (la resolución cambió a 16:9) pero volvía a la normal a los ~2 s, justo al abrir el panel de transmisión.
- Causa (confirmada en el código): `MainActivity.onCreate` llamaba a `restorePendingResize()` («restaurar al abrir la app por si quedó pendiente»); el cambio de densidad recreaba la Activity (el manifest no tenía `density` en `configChanges`), `onCreate` volvía a correr y la restauración deshacía el cambio recién aplicado. Error de diseño mío.
- Correcciones: se eliminó la restauración automática al abrir; `density` agregado a `configChanges` (la Activity ya no se recrea al cambiar la resolución); `NativeMirrorFlow` ya no restaura por tiempo ni al desconectarse (modo global hasta que el usuario restaure; `restoreOnDisconnect` queda como opción, desactivada); el inicio muestra el botón «Resolución 16:9 forzada · Restaurar» mientras haya algo pendiente.
- Restauración: «Detener y restaurar» / «Restaurar resolución» en el espejo nativo, el botón del inicio, o por Termux (`rish -c "wm size reset"`, `wm density reset`).
- Etiqueta: «módulo 3G-3 (16:9 persistente)». Verificado en la JVM: 172 pruebas (el modo persiste al conectar y desconectar, y mientras no se conecte ninguna pantalla). NO verificado: compilación; que la resolución se mantenga con el panel del sistema abierto en el Redmi 14C; que Miracast acepte el cambio.

### Módulo 3H: 16:9 manual en dos pasos, solo tamaño, panel de transmisión desde la Activity
Reporte real (3G-3): la resolución se queda fija (bien), pero el panel de transmisión de Xiaomi se abría errático (cruzado con Wi-Fi/red) y `wm density` desordenaba los íconos del escritorio.
- Íconos (hipótesis NO verificada): al cambiar la densidad para conservar el ancho en dp, la altura en dp baja (≈360×640 vs 360×820) y el launcher pierde filas y vuelve a guardar posiciones. Solo tamaño mantiene la altura en dp (≈540×960). `ScreenResizer.apply(changeDensity=false)` por defecto; la restauración solo toca la densidad si OpenTV la cambió (`PendingResize.densityChanged`, persistido). OpenTV NO puede deshacer un desorden ya ocurrido ni garantizar que no ocurra.
- Botón manual: `NativeMirrorFlow` ahora son dos pasos del usuario: «Forzar 16:9» y «Abrir transmisión» (estado `Forced(size, tvConnected, panelNote)`); la resolución no se restaura sola.
- Panel: `SystemCastLauncher.open(from)` usa la Activity visible (sin NEW_TASK). Si no abre, se indica el botón «Emitir/Smart View» del panel rápido. Comportamiento en HyperOS NO verificable aquí.
- Compatibilidad: la pantalla avisa si el teléfono no parece tener Miracast (sin pantalla de transmisión o sin Wi-Fi Direct) y remite al DLNA propio.
- Etiqueta: «módulo 3H (16:9 manual, solo tamaño)». Verificado en la JVM: 176 pruebas. NO verificado: compilación Android, cambios de UI, nada en hardware.

### Módulo 3H-2: rotación fija en horizontal con el 16:9
Reporte real (3H): íconos bien con solo tamaño; pero al girar la pantalla (o si una app pide horizontal) con 1080x1920 forzado la pantalla se parte/marea.
- Hipótesis NO verificada: el tamaño forzado es vertical y la rotación a mitad del espejo choca con él. Medida: al forzar 16:9 se fija la rotación en horizontal (`settings put system accelerometer_rotation 0` y `user_rotation 1`), guardando los valores previos en `PendingResize` (persistidos) y devolviéndolos al restaurar (borra `user_rotation` si no existía). Mejor esfuerzo: si falla, el 16:9 sigue igual. Lista blanca ampliada solo a esos dos ajustes.
- Sin cambios en el panel de transmisión (sigue pendiente la causa del desvío a Wi-Fi; hace falta ver qué intent abre Xiaomi).
- Etiqueta «módulo 3H-2 (16:9 + rotación fija)». Verificado en la JVM: 180 pruebas. NO verificado: compilación, hardware.

### Módulo 3H-2 (ampliado): asistente de Shizuku + espejo por navegador (MJPEG)
Pedido del usuario: mismo módulo 3H-2 (se conservan el arreglo de íconos —solo `wm size`— y la rotación horizontal fija), más (a) asistente interno de Shizuku y (b) servidor HTTP/MJPEG para teléfonos sin Miracast.
- Asistente (`display/ShizukuGuide`, pura, 5 pruebas; pantalla `ui/shizuku`, ruta `shizuku-guide`): 5 pasos (instalar, opciones de desarrollador, depuración inalámbrica, iniciar/emparejar, permiso) que se tildan por el estado REAL de Shizuku; botones para abrir la tienda/GitHub, opciones de desarrollador, Shizuku y pedir el permiso. Se abre desde «Espejo nativo» mientras Shizuku no esté lista. Límite honesto: Shizuku no puede embeberse ni activarse sola (Android exige la depuración inalámbrica del usuario) y se apaga al reiniciar.
- Espejo por navegador: `stream/MjpegHub` (solo el último cuadro; sin acumulación), `MjpegHttpServer` (HTTP/1.0, `/<código>/`, `stream.mjpg`, `snapshot.jpg`, `lento` con recarga automática para navegadores muy viejos; solo red local; máx. 4 clientes; repite el último cuadro si la pantalla no cambia), `MjpegPages`, `MjpegQuality` (Baja/Media/Alta), `BrowserMirror` (MediaProjection → ImageReader → JPEG; reutiliza `ProjectionService`; notificación con «Detener»), pantalla `ui/browser` (ruta `browser`, tarjeta «Espejo por navegador» en el inicio). Solo HTTP (no HTTPS: sin certificado válido en red local y los TV viejos no abren TLS moderno).
- Etiqueta sin cambios: «módulo 3H-2 (16:9 + rotación fija)». Verificado en la JVM: 193 pruebas (incluye servidor MJPEG real por sockets de loopback). NO verificado: compilación Android, captura/JPEG en el Redmi 14C, el navegador del TV, rendimiento/retraso real.

### Módulo 5A-R: nueva Fase 5A desde la base H2 (zona 16:9 intacta)
Pedido del usuario: descartar la 5A anterior y partir del ZIP estable H2; interfaz estilo Android TV y conectividad solo si no toca la resolución.
- Base: H2 sin cambios en `display/*`, `stream/TvProjection`, `ui/mirror/*`, `ui/remote/RemoteViewModel`, `AppContainer`, `OpenTvApp`, `MainActivity`, manifiesto y Gradle (comparado archivo por archivo con `cmp`).
- Inicio estilo Android TV: panel destacado que cambia con el foco, filas «Aplicaciones», «Transmitir TV» y «Más». Cada tarjeta solo ABRE una pantalla existente; el 16:9 se activa y restaura únicamente en su pantalla de H2 («Espejo nativo 16:9»). `HomeViewModel` solo agrega `openNativeCast` (abre el panel del sistema).
- Espejo por navegador (rescatado de 5A, sin llamadas a la resolución): dirección corta `http://IP:8080` (puertos 8080/8081/8888), páginas que ajustan la imagen sin deformarla, 2 hilos de JPEG, lista de pedidos recibidos para saber si el TV llegó.
- Guardia estática `ProtectedResolutionGuardTest` (7 pruebas): falla si algo fuera de la lista de H2 aplica/restaura la resolución, ejecuta `wm`/`settings`, usa `changeDensity = true`, o si el arranque, la red o `HomeScreen` mencionan el resizer. Probada con una mutación (detectó el cambio y se revirtió).
- Etiqueta «módulo 5A-R». Verificado en la JVM: 203 pruebas, también con el frontend Kotlin 1.9. NO verificado: compilación Android (la hace GitHub Actions), interfaz y red en hardware.
- Pospuesto a módulos propios: audio del sistema, canal local/M3U, modos por TV (`ConnectModes`), silenciar el teléfono, cualquier cambio en el 16:9.

### Módulo 5A-R3: 16:9 y rotación — se revierte el cambio de R2 (zona protegida intacta)
El módulo 5A-R2 había modificado `ScreenResizer.apply` (liberar la rotación antes de `wm size`). Por pedido expreso del usuario («debe permanecer EXACTAMENTE como está») se REVIERTE: `ScreenResizer.kt` y `ScreenResizerTest.kt` vuelven a ser idénticos a H2 (comparados con `cmp`).
- Diagnóstico y opciones: `docs/DIAGNOSTICO-ORIENTACION.md`. Conclusión: no se puede demostrar una corrección segura sin tocar la secuencia protegida; se aplica la opción C.
- Opción C: aviso fijo en el Inicio (solo texto, no ejecuta nada): «Para utilizar correctamente el modo 16:9, activá la rotación automática del teléfono desde la barra de notificaciones y volvé a utilizar la función 16:9.»
- Etiqueta «módulo 5A-R3». 203 pruebas en la JVM (K2 y 1.9). NO verificado: compilación Android ni hardware.

### Módulo 5B: medición de captura y codificación (aislada, solo mide)
Pedido del usuario: medir FPS reales de captura y codificación del Redmi 14C, sin tocar la zona protegida y sin presentarlo como solución al lag de Miracast.
- Nuevo paquete `bench/`: `BenchLogic` (pura, 10 pruebas), `AndroidEncoderLookup` (MediaCodecList, solo lectura), `BenchSession` (captura y codificación), `BenchHub` (estado y ciclo de vida), `BenchmarkService` (servicio propio, tipo mediaProjection), `ThermalProbe` (estado térmico de Android y temperatura de batería, públicos), `BenchViewModel`, `BenchScreen`.
- Qué mide, por configuración: (1) solo captura (pantalla virtual → ImageReader, cada cuadro se cuenta y se descarta sin leerlo); (2) captura + codificación H.264 por Surface (se cuentan las salidas del codificador). FPS promedio y mínimo/máximo por segundo sobre una ventana que excluye el primer segundo; bitrate medido de toda la prueba. Solo se ofrecen 720p/1080p a 30 y 60 FPS que `MediaCodecList` informe como compatibles; las demás se listan como no compatibles y no se fuerzan.
- «No disponible»: cuadros perdidos (la captura directa al codificador no los informa de forma fiable), latencia, y cualquier dato que Android no entregue. La temperatura es la de la batería y el estado térmico de Android; NO es la del procesador.
- Aislamiento: no usa `ScreenResizer`, `display/`, `TvProjection` ni `ProjectionService`; no cambia resolución, densidad ni rotación. Solo arranca desde su pantalla (botón + permiso de captura de Android); se detiene al salir de la pantalla, con «Detener», o si se revoca el permiso; libera pantalla virtual, codificador, captura y servicio.
- Android 14: una autorización = una pantalla virtual; entre pruebas se usa `resize` y `setSurface` en lugar de crear otra.
- Cambios fuera del paquete (justificados): `Routes.BENCH`, ruta en `OpenTvNavHost`, tarjeta «Medición de captura» en `HomeScreen`, UN `<service>` en el manifiesto (el existente dice «espejando en el TV» y su botón detiene la proyección), etiqueta, y la guardia ahora también prohíbe que `bench/` mencione el resizer.
- Verificado en la JVM: 213 pruebas (K2 y 1.9). NO verificado: compilación Android (la hace GitHub Actions), ninguna medición en hardware, comportamiento de `setSurface`/`resize` y del codificador en HyperOS.

## Miracast · etapa A (descubrimiento Wi-Fi Direct) — sin ZIP ni APK

Alcance: SOLO descubrir dispositivos Wi-Fi Direct con la API pública y mostrar lo que Android informa. No conecta, no forma grupos, no abre sockets, no negocia RTSP, no usa APIs ocultas ni reflexión, no toca resolución/densidad/rotación.

- Nuevo paquete `miracast/`: `P2pDiscoveryLogic.kt` (puro), `P2pDiscovery.kt`, `P2pDiscoveryViewModel.kt`, `P2pDiscoveryScreen.kt`, y `WfdVideoFormats.kt` (decodificador puro de `wfd_video_formats`, tablas verificadas contra AOSP; todavía sin uso desde la app).
- Cambios en archivos existentes (mínimos): `AndroidManifest.xml` (+ACCESS_WIFI_STATE, +CHANGE_WIFI_STATE, +NEARBY_WIFI_DEVICES con neverForLocation; SIN permiso de ubicación), `Routes.kt` (+P2P_DISCOVERY), `OpenTvNavHost.kt` (+1 ruta), `HomeScreen.kt` (+1 tarjeta que solo navega), `BuildInfo.kt` (etiqueta), `ProtectedResolutionGuardTest.kt` (+`miracast/` en la lista de código que no puede mencionar la zona protegida).
- Android 12 o anterior: Wi-Fi Direct exige ubicación según la guía oficial; no se declara sin aprobación, la pantalla indica que no se ejecuta.
- Verificado: 236 tests JVM (lógica pura) con frontend Kotlin 1.9 y 2.0; 14 archivos protegidos idénticos a H2 (cmp). NO verificado: compilación Android (no hay SDK acá) ni ejecución en teléfono.

## Miracast · etapa B (diagnóstico WFD) + rediseño Android TV — ZIP para GitHub Actions

### Etapa B: diagnóstico de negociación Wi-Fi Display (solo diagnóstico)
- Nuevo en `miracast/`: `WfdRtsp.kt` (puro: mensajes y parser RTSP, M1/M2/M3), `WfdDiagnosticLogic.kt` (puro: fases, resultados, textos que separan «recibido del televisor», «decodificado por OpenTV» e «inferencias»), `WfdDiagnosticSession.kt` (API pública `WifiP2pManager.connect` + socket en el puerto 7236 solo sobre la interfaz del grupo), `WfdDiagnosticViewModel.kt`, `WfdDiagnosticScreen.kt`.
- Seguridad: nunca conecta solo; el usuario elige un dispositivo detectado, confirma en un diálogo (foco inicial en «Cancelar») y puede cancelar en cualquier momento. Si el grupo formado no corresponde al dispositivo elegido, no lo toca. No envía M4 en adelante (no transmite video). No usa APIs ocultas, reflexión ni privilegios. No cambia el Wi-Fi del televisor ni su conexión a la red.
- Limitación conocida (hipótesis, sin verificar en hardware): una app común no puede anunciarse como fuente Wi-Fi Display (`setWfdInfo` es API del sistema), por lo que el televisor podría no abrir la conexión TCP. En ese caso el resultado es «no concluyente» y la pantalla dice exactamente en qué fase se detuvo. Nada de esto demuestra ni descarta los 60 FPS.
- Sin permisos nuevos respecto de la etapa A. En Android 12 o anterior `connect` exige ubicación según la guía oficial: no se declara; la pantalla lo informa.

### Rediseño Android TV
- Nuevo `ui/shell/`: `OpenTvShell` (barra superior fija: Inicio, Aplicaciones, Multimedia, Conexiones, Ajustes + reloj + engranaje), `ShellLogic` (secciones y catálogo de accesos, puro), `NetworkInfoLogic` (puro), `SystemAccess` (lectura de red sin SSID y apertura de pantallas oficiales de Android).
- `HomeScreen` reescrito: banner con el texto del elemento enfocado (sin imágenes ni contenidos inventados), apps favoritas, aviso 16:9 intacto, botón «Resolución 16:9 forzada · Restaurar» intacto, filas «Transmitir» y «Explorar», restauración de foco. `AppsScreen` suma modo `embedded`.
- Nuevas: `ui/media/MediaScreen`, `ui/connections/ConnectionsScreen` (separa descubrir / conectar / reproducir / duplicar pantalla), `ui/settings/SettingsHubScreen` (categorías + detalle; solo controles que funcionan o enlaces a ajustes de Android). Las tarjetas «Medición de captura», «Descubrimiento Wi-Fi Direct» y «Asistente de Shizuku» pasaron a Ajustes › Diagnósticos con los mismos destinos. `SettingsScreen.kt` queda sin uso (no se borró).
- Verificado: 265 tests JVM (lógica pura) con Kotlin 1.9 y 2.0; archivos protegidos y Gradle idénticos a H2 (cmp); manifiesto idéntico al de la etapa A. NO verificado: compilación Android, pantallas en Android, ni ninguna negociación con un receptor real.

## Rediseño R1–R3: Inicio cinematográfico + catálogo TMDB/RPDB (solo información)

### R1 · maquetación
- Nuevo `ui/tv/`: `TvLayout` (métricas puras: alto de tarjetas para el peor texto, héroe proporcional, escala por tamaño de fuente), `TvSafeArea` (margen 3 %), `ActionCard`, `BackdropHero`, `PosterCard`. Textos con `maxLines` + elipsis para que nada quede cortado en los bordes.
- `HomeScreen` rediseñado (banner grande, favoritas, filas). Se conservan: aviso de rotación, botón «Resolución 16:9 forzada · Restaurar», foco con joystick, Atrás.

### R2 · catálogo real (paquete `catalog/`)
- TMDB: tendencias, películas populares, series populares y próximos estrenos (es-AR). Caché en disco con vencimiento (filas 6 h, configuración 7 d), imágenes con `LruCache` por bytes + caché en disco + `inSampleSize` (poca memoria). Si hay datos guardados nunca queda la pantalla en blanco; errores de red, credenciales inválidas y catálogo vacío tienen mensaje propio.
- RPDB: carteles personalizados opcionales; si fallan o la clave es inválida se vuelve al cartel de TMDB.
- Credenciales: se cargan en Ajustes › Catálogo (probar conexión, estado, borrar). Se guardan en almacenamiento privado de la app cifradas con una clave del Android Keystore; `allowBackup=false`. NO están en el código, la documentación ni el ZIP (hay un test que lo vigila). Límite honesto: esto no impide que alguien con root o con acceso al dispositivo las extraiga.
- Todo lo del catálogo se rotula «Solo información»: no reproduce. «Fuentes de reproducción › Add-on» figura como «Pendiente».
- Atribución TMDB en texto. Pendiente de confirmar: redacción/logo exactos de los términos de TMDB y formato del id de TMDB en RPDB.

### R3 · pulido
- Acceso «Catálogo (TMDB)» desde Multimedia. `BuildInfo.LABEL` actualizado.

### Verificación real de esta tanda
- 299 tests JVM (lógica pura, incluida la del catálogo con red simulada) con Kotlin 1.9 y 2.0: OK.
- 14 archivos protegidos, `display/`, `ui/mirror`, `ui/shizuku` y archivos Gradle: idénticos a H2 (`cmp`). Manifiesto idéntico al ZIP anterior.
- NO verificado: compilación Android (no hay SDK ni acceso a Maven en el entorno; la compila GitHub Actions), pantallas en el teléfono, recortes de texto reales, foco con joystick sobre las pantallas nuevas, llamadas reales a TMDB/RPDB.

## Fase 6: IPTV, protocolo OpenTV Link, inventario de conexiones
- **IPTV** (`iptv/`, `ui/iptv/`): el teléfono emite su pantalla como canal en vivo (HLS v3 + TS directo + lista M3U) con servidor HTTP propio y servicio en primer plano propio (`IptvService`, sin permisos nuevos). Validado con ffmpeg/ffprobe reales (formato) y JUnit; **sin probar en el teléfono, el LG ni SmartOne**. Ver `docs/IPTV.md`.
- **OpenTV Link v1** (`proto/`, `tools/receiver-py/`): protocolo propio (tramas, ECDH+SAS, reconexión con secreto, AES-256-GCM, control de bitrate). Probado emisor Kotlin ↔ receptor Python en loopback. **Sin emisor/receptor en la app Android todavía.** Ver `docs/PROTOCOLO-OPENTV.md`.
- **Conexiones** reorganizada: duplicación, Emisión IPTV, Transmisión OpenTV (pendiente), dispositivos DLNA, diagnóstico.
- Documentos: `docs/CONEXIONES-INVENTARIO.md` (matriz y decisiones), `docs/REA.md` (respuesta: NO).
- Hallazgo de seguridad corregido: JCA no valida que un punto ECDH esté en la curva; se comprueba a mano (`OtCrypto.decodePublic`) con prueba.
- Manifiesto: solo se agregó `<service .iptv.IptvService>` (mismos permisos ya declarados).
- No se tocó DLNA, navegador ni Wi-Fi Direct (sin hardware para medir); ver el inventario para lo pendiente.

## Fase 6.1: audio real, perfiles 60 FPS, prueba de otro equipo (IPTV)
- **Audio real**: `iptv/PlaybackAudioEncoder.kt` captura el audio que reproduce el teléfono (AudioPlaybackCapture, Android 10+) con la misma MediaProjection y lo codifica en AAC-LC/ADTS al flujo TS. Requiere **RECORD_AUDIO** (único permiso nuevo; justificación en el manifiesto; se pide al iniciar; si se niega, la emisión sigue con pista en silencio y la pantalla lo dice). Se mide el nivel (umbral −70 dBFS): solo se muestra «capturando y se detecta sonido» si hubo muestras no nulas; si la app de origen bloquea la captura, se avisa. NO verificado en hardware.
- **Perfiles**: se agregan 720p60 y 1080p60. `IptvProfilePicker` consulta `MediaCodecList`/`areSizeAndRateSupported` y baja al perfil siguiente si el codificador no lo declara; `AvcLevels` calcula el nivel H.264 correcto (720p60 = 3.2, 1080p60 = 4.2) y `ScreenEncoder` lo acepta como parámetro opcional (por defecto conserva el comportamiento anterior, TvProjection no cambia). Que lo declare no prueba que lo sostenga: los FPS reales se miden en el teléfono.
- **1080i**: no se implementa. MediaCodec no expone codificación entrelazada; emitir «1080i» sería rotular un flujo progresivo. Si un TV lo exige, la conversión debe hacerla el receptor. No medido.
- **Dirección corta** (`/tv`, ciclo con «Dirección») o con código aleatorio.
- **Pedidos de otros equipos**: el servidor distingue los pedidos del propio teléfono/loopback de los de otros equipos y la pantalla muestra cuántos y desde qué IP; abrir `status.json` en el teléfono ya no se confunde con conectividad del TV.
- Tests: 350 JVM OK (K2 y K1.9). Protegidos (29 archivos) idénticos a H2. NO verificado: compilación Android, captura de audio y 60 fps en el Redmi 14C, reproducción en el LG/SmartOne.

## Fase 6.2: Etapa A (IPTV medido) + inicio de Etapa C (navegador liviano)
- **Mediciones separadas** en pantalla: pedido/configurado vs FPS codificados medidos (contador del MediaCodec), kbit/s producidos por el codificador y kbit/s entregados a los equipos (bytes escritos por el servidor). FPS/audio que reproduce el televisor: no medibles desde el teléfono (se dice). Aviso cuando los FPS codificados quedan bajo 85 % de lo pedido.
- **Perfiles 480p y 360p** (30 fps, 1,5 y 0,8 Mbit/s, segmentos de 4 s) con tamaño propio en `ScreenEncoder` (parámetros opcionales; TvProjection no cambia).
- **Página `http://IP:8090/`** (solo con dirección corta): HTML mínimo + script ES3, sin recursos externos, enlaces HLS/TS/sin reproductor, y `/diag` por el que el navegador informa `canPlayType`, si el video arrancó o falló; se muestra en el teléfono. Con código aleatorio la raíz da 404.
- **Audio**: nuevos estados NO_PERMISSION, UNAVAILABLE y CAPTURING_ZEROS (la captura activa que solo entrega ceros se informa como «nada suena o la app bloquea», porque Android no permite distinguirlo).
- `docs/PRUEBAS-FISICAS.md` registra tus pruebas Noblex y LG con lectura honesta.
- Tests: 362 JVM OK (K2 y K1.9). NO verificado: compilación Android, nada en el teléfono ni en los televisores.

## Fase 6.3 (acumulada): etapas A–G en una sola versión
- **A · 60 fps medidos**: `EncoderProbe` (MediaCodecList: hardware, tamaño/FPS declarados), `EncoderBenchmark` (codifica a la frecuencia pedida y cuenta cuadros reales), `PerfAdvisor` (prefiere 1080p60 > 720p60 > 1080p30 …; «sostenido» = ≥ 90 % de lo pedido). Modo automático + botón «Medir»; resultado guardado. Se distinguen pedido / configurado / codificado / entregado; el FPS del receptor no es medible desde el emisor y se dice. 1080i no se implementa (MediaCodec no entrelaza).
- **B · Audio**: sin cambios de permisos; estados de audio unificados en pantalla, notificación y página.
- **C · Navegador universal**: nuevo MP4 fragmentado (`Fmp4Muxer`, `/live.mp4`, validado con ffmpeg/ffprobe: decodifica, H.264 Main + AAC LC). La página `/` prueba HLS → MP4 → TS (primero lo que `canPlayType` declara), cae al siguiente por error o a los 12 s y, si nada reproduce, informa límites y alternativas.
- **D · OpenTV Link nativo** (`link/`, `proto/`, `ui/link/`): emisor (captura, codificación por hardware, servidor TCP 8765, emparejado ECDH P‑256 + código de 6 dígitos, AES‑256‑GCM, control de bitrate por estadísticas del receptor) y receptor (ExoPlayer sobre `TsDataSource`, reconexión automática con secreto guardado, descubrimiento NSD `_opentv._tcp`). Entradas reales en el menú.
- **E · Wi‑Fi Direct**: `P2pConnectPlanner` (puro) ordena limpieza → descubrir en el mismo canal → esperar estado del par → `connect()`; BUSY reintenta, ERROR(0) reinicia el canal hasta 2 veces y luego explica hechos medidos / hipótesis / límite real de la API (`WifiP2pWfdInfo` oculta: una app no puede anunciarse como fuente WFD). El efecto sobre el error 0 NO está probado.
- **F · DLNA / espejo**: archivos protegidos sin tocar; el espejo por navegador se resuelve con la página `/` de IPTV (audio+video). DLNA sigue siendo envío de contenido, no espejo real.
- **G · Notificación general**: `TransmissionRegistry` + `IptvService` (id 4102): tecnología, resolución, FPS, bitrate, audio y «Detener» para IPTV y Link. Miracast/DLNA nativos (ProjectionService, protegido) no entran.
- **Tests**: 392 JVM OK (K2 y K1.9). Chequeo de tipos contra stubs escritos a mano: 0 errores (K2 y K1.9) en el código Android sin Compose/media3.
- **NO realizado**: compilación Android real (no hay SDK ni Maven en este entorno; la confirma GitHub Actions), pantallas Compose, `TsDataSource`, edición de `WfdDiagnosticSession`, manifiesto y nada en teléfono ni televisores.
- Protegidos idénticos a H2 (`FocusableSurface` conserva el cambio de 6.2, idéntico a esa entrega).

## Fase 6.4: corrección de rumbo de OpenTV Link, audio solo en TV, ciclo de vida IPTV, catálogo
- **OpenTV Link = teléfono → televisor/receptor HDMI** (no teléfono↔teléfono): el receptor escucha y se anuncia; el teléfono lo elige y se conecta; ventana de emparejamiento de 2 minutos; el emisor reintenta solo. Textos de menú y pantallas corregidos. Documento: `docs/OPENTV-LINK-ARQUITECTURA.md` (límites de LG NetCast y receptor HDMI).
- **IPTV, corte al salir de la pantalla**: no se encontró una causa en la pantalla (el canal vive en `IptvController`). Se agregaron `TransmissionLocks` (CPU + Wi‑Fi, permiso normal `WAKE_LOCK`, único permiso nuevo) y el **motivo de cada parada** («Última parada»). La causa real queda por confirmar en el Noblex.
- **Audio solo en TV (experimental)**: `LocalMuteJudge` (lógica pura, 9 pruebas) + `LocalAudioMuter`: espera sonido, baja el volumen multimedia del teléfono y mide si la captura sigue recibiendo sonido; si cae a silencio, restaura y lo dice. Botón en la pantalla IPTV. No confirma lo que oye el televisor.
- **CatalogLogicTest**: línea 211 con smart cast sobre `r.problem` (propiedad de otro módulo) → variables locales tipadas. Nuevo `runit2.py` compila main y test como módulos separados y reproduce ese error exacto con la versión anterior del archivo (antes el arnés lo ocultaba).
- Auditoría de todas las conexiones: `docs/AUDITORIA-CONEXIONES.md`.
- Tests: 404 JVM OK (K2 y K1.9, módulos separados). NO verificado: compilación Android real, pantallas Compose, nada en dispositivos.

## Fase 6.5: corte de IPTV, ritmo de cuadros, compatibilidad, audio en Link
- Pruebas de la 6.4 (APK compilado por Actions): ver `docs/IPTV-CORTE-Y-60FPS.md` y `docs/COMPATIBILIDAD-TELEVISORES.md`.
- **FramePump** (OpenGL ES): la pantalla virtual → `SurfaceTexture` → hilo GL → codificador a FPS fijos, con respaldo a captura directa. Ataca la causa más probable del corte (cuadros que dejan de llegar con pantalla quieta). Botón para desactivarlo.
- **Estado verificado**: «salud» basada en cuadros codificados recientes y datos entregados; métricas separadas (solicitado, capturado, entregado al codificador, codificado, bitrate producido/entregado; recibido/Hz del TV: no disponible).
- **Motivos de parada** ampliados (codificador, servidor, captura, red) y detalle técnico; el servidor y el codificador avisan si terminan solos.
- **Historial HTTP** con IP, agente de usuario, bytes y cierres; lista `plain.m3u` mínima; perfiles 480p/360p con H.264 Baseline; mensaje de la página raíz más claro.
- **Perfil manual** ya no se baja por consulta previa.
- **Audio solo en TV** compartido (`SoloTvAudio`) y activo también en OpenTV Link.
- Tests: 414 JVM OK (K2 y K1.9, main y test por separado). NO verificado: compilación Android real de esta versión, el GL en dispositivos, nada físico.

## Fase 6.6 (conectividad)
- Wi‑Fi Direct: ya no se llama a `connect()` con un par que el sistema no lista (hipótesis, sin confirmar en equipo: así se producía el error 0). Se repite el descubrimiento hasta 3 veces y se resuelve el par por nombre si cambió su dirección. `P2pPeerMatcher`, `P2pConnectPlanner` (RESCAN / NOT_VISIBLE). Tests nuevos.
- IPTV y Link: `FpsGovernor` (60→30→24→15, con causa: dibujado, codificador, temperatura, red). Ajusta en vivo el ritmo de la bomba de cuadros y el bitrate, sin otro permiso.
- Espejo por navegador: `MjpegAdaptive` baja o sube la calidad JPEG según lo producido contra lo enviado (pantalla quieta ≠ congestión). Muestra cuadros producidos y calidad.
- NO hecho (ver informe): DLNA (está en `connect/`, protegido), mejoras de Miracast nativo, audio en navegador, transporte propio sobre Wi‑Fi Direct, compilación Android real.

## Fase 6.7
- Instrumentación de microcortes (intervalos, cuadros tardíos, entrega por segmento, marcas GL, gobernador conmutable): implementada, probada en JVM la parte pura; **efecto sobre los cortes no verificado**.
- MJPEG: contador de repetidos vs nuevos. Wi-Fi Direct: estado previo a `connect()` registrado.
- DLNA independiente (`media/dlna/`): ver `docs/DLNA-INDEPENDIENTE.md`. UI en la pantalla IPTV.
- Receptor PS3: núcleo C probado en PC; capa PS3 sin compilar ni probar (`docs/PS3-RECEPTOR.md`).
- No hecho: mejoras de OpenTV Link para receptores no-Android (capacidades en HELLO, código en pantalla, reanudación), alternativas de navegador para LG NetCast, cifrado en el receptor PS3.
