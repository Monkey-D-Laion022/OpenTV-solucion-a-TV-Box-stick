package com.opentv.app.miracast

import android.annotation.SuppressLint
import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.wifi.WpsInfo
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Looper
import android.os.SystemClock
import androidx.core.content.ContextCompat
import java.io.IOException
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/** Estado visible de una prueba de la etapa B. */
data class WfdUi(
    val running: Boolean = false,
    val started: Boolean = false,
    val observation: WfdObservation = WfdObservation(),
    val steps: List<WfdStep> = emptyList(),
    val log: List<String> = emptyList(),
)

/**
 * Etapa B: diagnóstico de la negociación Miracast/WFD con UN dispositivo elegido y confirmado por el usuario.
 *
 * Qué hace, en orden: pide la conexión Wi-Fi Direct (con la API pública), espera el grupo, abre el puerto RTSP en la
 * dirección del grupo y espera a que el televisor se conecte; si lo hace, intercambia M1/M2/M3 y lee sus capacidades.
 * Qué NO hace: no anuncia a OpenTV como fuente Wi-Fi Display (eso es API de sistema), no usa APIs ocultas ni reflexión,
 * no envía M4/M5, no hace SETUP/PLAY y no transmite video. Siempre se puede cancelar y todo se libera al terminar.
 */
@SuppressLint("MissingPermission")
class WfdDiagnosticSession(private val app: Application, private val scope: CoroutineScope) {
    private val _ui = MutableStateFlow(WfdUi())
    val ui: StateFlow<WfdUi> = _ui.asStateFlow()

    private var manager: WifiP2pManager? = null
    private var channel: WifiP2pManager.Channel? = null
    private var receiver: BroadcastReceiver? = null
    private var groupTimeout: Job? = null
    private var ioJob: Job? = null
    private var serverSocket: ServerSocket? = null
    private var clientSocket: Socket? = null

    @Volatile private var cancelRequested = false
    /** Si hay captura concedida, tras M3 se continúa el protocolo y se transmite (Miracast completo). */
    @Volatile private var streamRequest: com.opentv.app.stream.MirrorRequest? = null
    @Volatile private var streamAudio = false
    private var streamer: WfdSourceStreamer? = null
    @Volatile private var groupHandled = false
    private var ended = true
    private var ownsGroup = false
    private var retries = 0
    private var planner = P2pConnectPlanner()
    private var sawPeer = false
    private var lastPeerStatus: Int? = null
    private var startedAt = 0L
    private var peerAddress: String = ""
    private var peerName: String = ""

    fun hasPermission(): Boolean =
        Build.VERSION.SDK_INT >= P2pPolicy.FIRST_SDK_WITHOUT_LOCATION &&
            ContextCompat.checkSelfPermission(app, P2pPolicy.NEARBY_PERMISSION) == PackageManager.PERMISSION_GRANTED

    /** Inicia la prueba con [peer]. Solo se llama después de la confirmación explícita del usuario. */
    fun start(peer: P2pPeer, request: com.opentv.app.stream.MirrorRequest? = null, captureAudio: Boolean = false) {
        streamRequest = request; streamAudio = captureAudio
        if (_ui.value.running) return
        startedAt = SystemClock.elapsedRealtime()
        cancelRequested = false
        groupHandled = false
        ownsGroup = false
        retries = 0
        planner = P2pConnectPlanner()
        sawPeer = false
        lastPeerStatus = null
        ended = false
        _ui.value = WfdUi(running = true, started = true, observation = WfdObservation(peerName = peer.name))

        val address = peer.address
        if (address.isNullOrBlank()) {
            log("El dispositivo no informó una dirección utilizable: no se puede conectar.")
            updateObs { it.copy(connectAccepted = false) }
            finishRun()
            return
        }
        peerAddress = address
        peerName = peer.name
        if (!P2pPolicy.canRun(Build.VERSION.SDK_INT) || !hasPermission()) {
            log("Falta el permiso de dispositivos Wi-Fi cercanos o la versión de Android no lo permite.")
            updateObs { it.copy(connectAccepted = false) }
            finishRun()
            return
        }
        val m = app.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
        if (m == null) {
            log("El sistema no ofrece Wi-Fi Direct.")
            updateObs { it.copy(connectAccepted = false) }
            finishRun()
            return
        }
        manager = m
        val ch = m.initialize(app, Looper.getMainLooper(), null)
        channel = ch
        val rx = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (intent.action == WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION) onConnectionChanged()
            }
        }
        receiver = rx
        ContextCompat.registerReceiver(
            app, rx, IntentFilter(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION), ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        log("Prueba iniciada con «${peer.name}». Se puede cancelar en cualquier momento.")
        prepareThenConnect()
    }

    /**
     * Secuencia previa a connect(): limpiar solicitudes/grupos viejos, descubrir pares EN ESTE canal y esperar a ver el
     * televisor con su estado. Antes se conectaba directo sobre un canal recién creado (el error 0 de la prueba anterior).
     */
    private fun prepareThenConnect() {
        val m = manager ?: return
        val ch = channel ?: return
        log("Preparación: se limpian solicitudes y grupos previos y se descubre el televisor en este canal antes de conectar.")
        runCatching { m.cancelConnect(ch, null) }
        runCatching { m.removeGroup(ch, null) }
        scope.launch {
            delay(400)
            if (cancelRequested || ended) return@launch
            try {
                m.discoverPeers(ch, object : WifiP2pManager.ActionListener {
                    override fun onSuccess() { if (!cancelRequested && !ended) { log("Descubrimiento iniciado en este canal."); waitForPeer() } }
                    override fun onFailure(reason: Int) {
                        if (cancelRequested || ended) return
                        log("El descubrimiento previo falló: ${P2pText.failure(reason)}. Se revisa igual la lista de pares del sistema.")
                        waitForPeer()
                    }
                })
            } catch (e: SecurityException) {
                log("Excepción de seguridad al descubrir: ${e.message ?: "sin detalle"}.")
                updateObs { it.copy(connectAccepted = false) }
                step(WfdPhase.CONNECT_REQUEST, StepOutcome.FAILED, "Android negó el descubrimiento por seguridad: ${e.message ?: "sin detalle"}.")
                finishRun()
            }
        }
    }

    private fun waitForPeer() {
        scope.launch {
            var startWait = SystemClock.elapsedRealtime()
            while (!cancelRequested && !ended) {
                val match = peerStatus()
                val cand = match.candidate
                if (cand != null) {
                    sawPeer = true; lastPeerStatus = cand.status
                    if (match.addressChanged) {
                        log("El televisor cambió su dirección Wi‑Fi Direct desde el escaneo anterior; se usa la dirección vigente.")
                        peerAddress = cand.address
                    }
                }
                val waited = SystemClock.elapsedRealtime() - startWait
                val check = planner.onPeerCheck(cand != null, cand?.status, waited)
                when (check.action) {
                    P2pConnectPlanner.PeerAction.CONNECT -> { log(check.note); sendConnect(); return@launch }
                    P2pConnectPlanner.PeerAction.RESCAN -> {
                        log(check.note)
                        rediscover()
                        startWait = SystemClock.elapsedRealtime()
                    }
                    P2pConnectPlanner.PeerAction.NOT_VISIBLE -> {
                        log(check.note)
                        updateObs { it.copy(connectAccepted = false) }
                        step(WfdPhase.CONNECT_REQUEST, StepOutcome.FAILED, P2pConnectPlanner.explainNotVisible(planner.rescans, lastPeerStatus))
                        finishRun()
                        return@launch
                    }
                    P2pConnectPlanner.PeerAction.WAIT -> if (waited % 3_000L < 1_000L) log(check.note)
                }
                delay(1_000)
            }
        }
    }

    /** Reinicia el descubrimiento en este canal (la lista de pares del sistema caduca si no se refresca). */
    private fun rediscover() {
        val m = manager ?: return
        val ch = channel ?: return
        try {
            m.stopPeerDiscovery(ch, null)
            m.discoverPeers(ch, object : WifiP2pManager.ActionListener {
                override fun onSuccess() { log("Nuevo descubrimiento iniciado.") }
                override fun onFailure(reason: Int) { log("El nuevo descubrimiento falló: ${P2pText.failure(reason)}.") }
            })
        } catch (e: SecurityException) {
            log("Excepción de seguridad al redescubrir: ${e.message ?: "sin detalle"}.")
        }
    }

    /** El par vigente en la lista actual del canal (por dirección o, si cambió, por nombre único). */
    private suspend fun peerStatus(): P2pPeerMatcher.Match {
        val m = manager ?: return P2pPeerMatcher.Match(null, false)
        val ch = channel ?: return P2pPeerMatcher.Match(null, false)
        return suspendCancellableCoroutine { cont ->
            try {
                m.requestPeers(ch) { list ->
                    val cands = list?.deviceList.orEmpty().map { P2pPeerMatcher.Candidate(it.deviceAddress ?: "", it.deviceName ?: "", it.status) }
                    if (cont.isActive) cont.resume(P2pPeerMatcher.resolve(cands, peerAddress, peerName))
                }
            } catch (e: SecurityException) {
                if (cont.isActive) cont.resume(P2pPeerMatcher.Match(null, false))
            }
        }
    }

    /** Cierra el canal, abre uno nuevo y repite la secuencia (reinicio real del estado Wi‑Fi Direct de esta app). */
    private fun resetChannelAndRetry() {
        val m = manager ?: return
        channel?.let { old ->
            runCatching { m.cancelConnect(old, null) }
            runCatching { m.removeGroup(old, null) }
            if (Build.VERSION.SDK_INT >= 27) runCatching { old.close() }
        }
        channel = m.initialize(app, Looper.getMainLooper(), null)
        prepareThenConnect()
    }

    /** Cancela la prueba y libera todo (sockets, grupo creado por esta prueba, receptor y canal). */
    fun cancel() {
        if (!_ui.value.running) return
        cancelRequested = true
        log("Prueba cancelada por el usuario.")
        finishRun()
    }

    // ---- Fase 1: solicitud de conexión ----

    /** Experimento D4: deja en el registro cómo ve el sistema al televisor y si ya hay un grupo ANTES de conectar. */
    private fun logPreConnectState(m: WifiP2pManager, ch: WifiP2pManager.Channel) {
        try {
            m.requestPeers(ch) { list ->
                val d = list?.deviceList?.firstOrNull { it.deviceAddress.equals(peerAddress, ignoreCase = true) }
                log(
                    if (d == null) "Antes de conectar: el televisor no figura en la lista del sistema."
                    else "Antes de conectar: «${d.deviceName}» estado ${P2pText.status(d.status)}, tipo ${d.primaryDeviceType ?: "sin dato"}, " +
                        "${if (d.isServiceDiscoveryCapable) "con" else "sin"} descubrimiento de servicios.",
                )
            }
            m.requestGroupInfo(ch) { g ->
                log(
                    if (g == null) "Antes de conectar: no hay ningún grupo Wi‑Fi Direct activo en este teléfono."
                    else "Antes de conectar: ya hay un grupo activo (${g.networkName ?: "sin nombre"}, ${if (g.isGroupOwner) "este teléfono es propietario" else "este teléfono es cliente"}, ${g.clientList.size} cliente(s)).",
                )
            }
        } catch (e: SecurityException) {
            log("No se pudo leer el estado previo: ${e.message ?: "sin detalle"}.")
        }
    }

    private fun sendConnect() {
        val m = manager ?: return
        val ch = channel ?: return
        logPreConnectState(m, ch)
        val config = WifiP2pConfig().apply {
            deviceAddress = peerAddress
            wps.setup = WpsInfo.PBC
            // Igual que el controlador de Android: ayuda a la convivencia entre Wi-Fi normal y Wi-Fi Direct.
            groupOwnerIntent = 0
        }
        try {
            m.connect(ch, config, object : WifiP2pManager.ActionListener {
                override fun onSuccess() {
                    if (cancelRequested || ended) return
                    updateObs { it.copy(connectAccepted = true) }
                    step(
                        WfdPhase.CONNECT_REQUEST, StepOutcome.OK,
                        "Android aceptó enviar la solicitud. Si es tu televisor, mirá su pantalla y aceptá el pedido.",
                    )
                    armGroupTimeout()
                }

                override fun onFailure(reason: Int) {
                    if (cancelRequested || ended) return
                    val decision = planner.onConnectFailure(reason)
                    log(decision.note)
                    if (decision.kind != P2pConnectPlanner.Kind.GIVE_UP) {
                        retries++
                        scope.launch {
                            delay(decision.delayMs)
                            if (cancelRequested || ended) return@launch
                            if (decision.kind == P2pConnectPlanner.Kind.WAIT_AND_RETRY) sendConnect() else resetChannelAndRetry()
                        }
                        return
                    }
                    updateObs { it.copy(connectAccepted = false, connectFailureCode = reason) }
                    step(
                        WfdPhase.CONNECT_REQUEST, StepOutcome.FAILED,
                        "Android rechazó la solicitud: ${P2pText.failure(reason)}. " +
                            P2pConnectPlanner.explainFailure(reason, planner.resets, sawPeer, lastPeerStatus),
                    )
                    finishRun()
                }
            })
        } catch (e: SecurityException) {
            updateObs { it.copy(connectAccepted = false) }
            step(WfdPhase.CONNECT_REQUEST, StepOutcome.FAILED, "Excepción de seguridad: ${e.message ?: "sin detalle"}.")
            finishRun()
        }
    }

    // ---- Fase 2: formación del grupo ----

    private fun armGroupTimeout() {
        groupTimeout?.cancel()
        groupTimeout = scope.launch {
            delay(WfdTimeouts.GROUP_SECONDS * 1000L)
            if (!groupHandled && !cancelRequested && !ended) {
                updateObs { it.copy(groupFormed = false) }
                step(
                    WfdPhase.GROUP_FORMATION, StepOutcome.TIMEOUT,
                    "No se formó el grupo en ${WfdTimeouts.GROUP_SECONDS} s (el televisor no aceptó, no respondió o no es conectable).",
                )
                finishRun()
            }
        }
    }

    private fun onConnectionChanged() {
        if (groupHandled || cancelRequested || ended) return
        val m = manager ?: return
        val ch = channel ?: return
        try {
            m.requestConnectionInfo(ch) { info -> if (info != null && info.groupFormed) onGroupFormed(info) }
        } catch (e: SecurityException) {
            log("Excepción de seguridad al consultar la conexión: ${e.message ?: "sin detalle"}.")
        }
    }

    private fun onGroupFormed(info: WifiP2pInfo) {
        if (groupHandled || cancelRequested || ended) return
        groupHandled = true
        groupTimeout?.cancel()
        val m = manager ?: return
        val ch = channel ?: return
        val ownerAddress = info.groupOwnerAddress?.hostAddress
        try {
            m.requestGroupInfo(ch) { group ->
                if (cancelRequested || ended) return@requestGroupInfo
                val iface = group?.getInterface()
                val matches = group != null && (
                    group.owner?.deviceAddress.equals(peerAddress, ignoreCase = true) ||
                        group.clientList.any { it.deviceAddress.equals(peerAddress, ignoreCase = true) }
                    )
                updateObs {
                    it.copy(
                        groupFormed = true, weAreGroupOwner = info.isGroupOwner,
                        groupInterface = iface, groupOwnerAddress = ownerAddress,
                    )
                }
                if (!matches) {
                    // No se toca un grupo que no creó esta prueba.
                    step(
                        WfdPhase.GROUP_FORMATION, StepOutcome.FAILED,
                        "Se formó un grupo, pero no con el dispositivo elegido: no se usa ni se modifica.",
                    )
                    finishRun()
                    return@requestGroupInfo
                }
                ownsGroup = true
                step(
                    WfdPhase.GROUP_FORMATION, StepOutcome.OK,
                    "Grupo formado. Propietario: ${if (info.isGroupOwner) "este teléfono" else "el otro dispositivo"} · interfaz ${iface ?: "?"}.",
                )
                if (iface == null) {
                    step(WfdPhase.LISTENING, StepOutcome.FAILED, "Android no informó la interfaz del grupo.")
                    finishRun()
                } else {
                    ioJob = scope.launch(Dispatchers.IO) { runRtsp(iface) }
                }
            }
        } catch (e: SecurityException) {
            step(WfdPhase.GROUP_FORMATION, StepOutcome.FAILED, "Excepción de seguridad: ${e.message ?: "sin detalle"}.")
            finishRun()
        }
    }

    // ---- Fases 3 a 7: escucha RTSP y negociación M1/M2/M3 (hilo de red) ----

    private fun groupAddress(iface: String): InetAddress? = try {
        NetworkInterface.getByName(iface)?.inetAddresses?.toList()?.firstOrNull { it is Inet4Address }
    } catch (e: IOException) {
        null
    }

    private fun runRtsp(iface: String) {
        val local = groupAddress(iface)
        if (local == null) {
            updateObs { it.copy(listening = false) }
            step(WfdPhase.LISTENING, StepOutcome.FAILED, "No hay dirección IPv4 en la interfaz del grupo ($iface).")
            finishRun()
            return
        }
        val server = try {
            ServerSocket().apply {
                reuseAddress = true
                bind(InetSocketAddress(local, WfdTimeouts.RTSP_PORT))
                soTimeout = 1000
            }
        } catch (e: IOException) {
            updateObs { it.copy(listening = false) }
            step(WfdPhase.LISTENING, StepOutcome.FAILED, "No se pudo abrir el puerto ${WfdTimeouts.RTSP_PORT}: ${e.message ?: "sin detalle"}.")
            finishRun()
            return
        }
        serverSocket = server
        updateObs { it.copy(listening = true, localAddress = local.hostAddress) }
        step(
            WfdPhase.LISTENING, StepOutcome.OK,
            "Escuchando solo en ${local.hostAddress}:${WfdTimeouts.RTSP_PORT} (dirección del grupo), hasta ${WfdTimeouts.RTSP_SECONDS} s.",
        )

        var client: Socket? = null
        val deadline = SystemClock.elapsedRealtime() + WfdTimeouts.RTSP_SECONDS * 1000L
        while (!cancelRequested && client == null && SystemClock.elapsedRealtime() < deadline) {
            try {
                client = server.accept()
            } catch (e: SocketTimeoutException) {
                // sigue esperando
            } catch (e: IOException) {
                break
            }
        }
        runCatching { server.close() } // una sola conexión: se cierra la escucha de inmediato
        serverSocket = null
        if (cancelRequested || ended) {
            runCatching { client?.close() }
            return
        }
        if (client == null) {
            step(WfdPhase.TCP_FROM_TV, StepOutcome.TIMEOUT, "El televisor no abrió ninguna conexión TCP en ${WfdTimeouts.RTSP_SECONDS} s.")
            finishRun()
            return
        }
        clientSocket = client
        val remote = client.inetAddress?.hostAddress
        updateObs { it.copy(tvRemoteAddress = remote) }
        step(WfdPhase.TCP_FROM_TV, StepOutcome.OK, "El televisor se conectó desde $remote.")
        negotiate(client)
        finishRun()
    }

    private fun negotiate(client: Socket) {
        val deadline = SystemClock.elapsedRealtime() + WfdTimeouts.RTSP_SECONDS * 1000L
        val parser = RtspParser()
        val buffer = ByteArray(4096)
        var nextCseq = 1
        var m1Cseq = -1
        var m3Cseq = -1
        var m1Done = false
        var m2Done = false
        var m3Sent = false
        var m3Done = false
        var closedByTv = false
        var flow: WfdSourceFlow? = null
        var flowEnded = false
        var streaming = false
        var lastRtpLog = 0L

        try {
            client.soTimeout = 1000
            val input = client.getInputStream()
            val output = client.getOutputStream()

            fun send(text: String) {
                output.write(text.toByteArray(Charsets.ISO_8859_1))
                output.flush()
                log("Enviado: ${text.lineSequence().first()}")
            }

            m1Cseq = nextCseq++
            send(WfdRtsp.m1(m1Cseq))

            fun runFlow(f: WfdSourceFlow, msg: RtspMessage?, params: Map<String, String>?) {
                val before = f.state
                val (n, acts) = if (msg == null) f.start(params ?: emptyMap(), nextCseq) else f.onMessage(msg, nextCseq)
                nextCseq = n
                for (a in acts) when (a) {
                    is WfdAction.Send -> send(a.text)
                    is WfdAction.Log -> log(a.text)
                    is WfdAction.KeyFrame -> streamer?.requestKeyFrame()
                    is WfdAction.StartStream -> {
                        val req = streamRequest
                        val remote = client.inetAddress
                        if (req != null && remote != null) {
                            val st = WfdSourceStreamer(app, req, streamAudio) { why -> log(why); step(WfdPhase.STREAM, StepOutcome.FAILED, why) }
                            streamer = st
                            st.start(remote, a.clientPort, a.choice)
                            streaming = true
                            step(WfdPhase.STREAM, StepOutcome.OK, "Iniciando captura y envío de ${a.choice.mode.label} a ${remote.hostAddress}:${a.clientPort} por RTP/MPEG-TS (audio: ${a.choice.audio.label}). Esto NO prueba que haya transmisión: verificá que los paquetes RTP sean mayores que cero y que el televisor muestre imagen y sonido.")
                        }
                    }
                    is WfdAction.StopStream -> { streamer?.stop(); streaming = false }
                    is WfdAction.Fail -> { flowEnded = true; step(phaseOf(before), StepOutcome.FAILED, a.reason) }
                    is WfdAction.Done -> { flowEnded = true; log("El televisor cerró la sesión (TEARDOWN).") }
                }
                val after = f.state
                if (before == WfdSourceFlow.State.WAIT_M4 && after == WfdSourceFlow.State.WAIT_M5) step(WfdPhase.M4, StepOutcome.OK, "El televisor aceptó el formato ${f.choice?.mode?.label}.")
                if (before == WfdSourceFlow.State.WAIT_M5 && after == WfdSourceFlow.State.WAIT_SETUP) step(WfdPhase.M5, StepOutcome.OK, "El televisor aceptó el trigger SETUP.")
                if (after == WfdSourceFlow.State.WAIT_PLAY && before != after) step(WfdPhase.SETUP, StepOutcome.OK, "SETUP recibido y respondido.")
                if (after == WfdSourceFlow.State.STREAMING && before != after) step(WfdPhase.PLAY, StepOutcome.OK, "PLAY recibido y respondido.")
            }

            fun handle(msg: RtspMessage) {
                log("Recibido: ${msg.summary}" + if (msg.body.isNotBlank()) " · ${msg.body.trim().take(300)}" else "")
                val active = flow
                if (active != null && m3Done) { runFlow(active, msg, null); return }
                if (!msg.isRequest) {
                    when (msg.cseq) {
                        m1Cseq -> {
                            m1Done = true
                            updateObs { it.copy(m1Status = msg.statusCode, m1Public = msg.header("public")) }
                            step(WfdPhase.M1, if (msg.statusCode == 200) StepOutcome.OK else StepOutcome.FAILED, "Respuesta RTSP ${msg.statusCode}.")
                        }
                        m3Cseq -> {
                            m3Done = true
                            val params = WfdRtsp.parseParameters(msg.body)
                            updateObs { it.copy(m3Status = msg.statusCode, m3Params = params) }
                            step(
                                WfdPhase.M3, if (msg.statusCode == 200) StepOutcome.OK else StepOutcome.FAILED,
                                "Respuesta RTSP ${msg.statusCode} con ${params.size} parámetro(s).",
                            )
                            if (streamRequest != null && msg.statusCode == 200) {
                                val f = WfdSourceFlow(client.localAddress?.hostAddress ?: "0.0.0.0")
                                flow = f
                                runFlow(f, null, params)
                            }
                        }
                        else -> log("Respuesta con CSeq inesperado (${msg.cseq}): se ignora.")
                    }
                } else {
                    val cseq = msg.cseq ?: 0
                    when (msg.method) {
                        "OPTIONS" -> {
                            updateObs { it.copy(m2Method = msg.method, m2Public = msg.header("public"), m2Require = msg.header("require")) }
                            send(WfdRtsp.m2Response(cseq))
                            m2Done = true
                            step(WfdPhase.M2, StepOutcome.OK, "Recibido y respondido.")
                        }
                        "GET_PARAMETER" -> send(WfdRtsp.ok(cseq))
                        else -> {
                            send(WfdRtsp.notAllowed(cseq))
                            log("Método ${msg.method} no admitido en esta etapa (no se hace SETUP ni PLAY).")
                        }
                    }
                }
                if (m1Done && m2Done && !m3Sent) {
                    m3Cseq = nextCseq++
                    send(WfdRtsp.m3(m3Cseq))
                    m3Sent = true
                }
            }

            while (!cancelRequested && (!m3Done || (flow != null && !flowEnded)) && (streaming || SystemClock.elapsedRealtime() < deadline)) {
                val st = streamer
                if (streaming && st != null && SystemClock.elapsedRealtime() - lastRtpLog > 5000) { lastRtpLog = SystemClock.elapsedRealtime(); log(st.summary()) }
                val n = try {
                    input.read(buffer)
                } catch (e: SocketTimeoutException) {
                    0
                }
                if (n < 0) {
                    closedByTv = true
                    log("El televisor cerró la conexión.")
                    break
                }
                if (n > 0) {
                    parser.feed(buffer, n)
                    if (parser.overflow) {
                        log("El televisor envió datos que no son un mensaje RTSP válido o demasiado grandes: se corta.")
                        break
                    }
                    while (true) handle(parser.next() ?: break)
                }
            }
        } catch (e: IOException) {
            log("Error de red durante la negociación: ${e.message ?: "sin detalle"}.")
            closedByTv = true
        }

        streamer?.stop(); streamer = null
        if (cancelRequested) return
        // Fases que no llegaron a completarse: se registra por qué.
        val reason = if (closedByTv) StepOutcome.FAILED else StepOutcome.TIMEOUT
        val why = if (closedByTv) "conexión cerrada antes de completarse" else "sin respuesta en ${WfdTimeouts.RTSP_SECONDS} s"
        if (!m1Done) step(WfdPhase.M1, reason, "Sin respuesta al M1: $why.")
        if (!m2Done) step(WfdPhase.M2, reason, "El televisor no envió su M2: $why.")
        if (!m3Done) step(WfdPhase.M3, if (m3Sent) reason else StepOutcome.SKIPPED, if (m3Sent) "Sin respuesta al M3: $why." else "No se envió: faltó M1 o M2.")
    }

    // ---- Cierre ----

    @Synchronized
    private fun phaseOf(s: WfdSourceFlow.State): WfdPhase = when (s) {
        WfdSourceFlow.State.WAIT_M4 -> WfdPhase.M4
        WfdSourceFlow.State.WAIT_M5 -> WfdPhase.M5
        WfdSourceFlow.State.WAIT_SETUP -> WfdPhase.SETUP
        WfdSourceFlow.State.WAIT_PLAY -> WfdPhase.PLAY
        else -> WfdPhase.STREAM
    }

    private fun finishRun() {
        if (ended) return
        ended = true
        streamer?.stop(); streamer = null
        groupTimeout?.cancel()
        groupTimeout = null
        runCatching { clientSocket?.close() }
        runCatching { serverSocket?.close() }
        clientSocket = null
        serverSocket = null

        // Las fases que no se alcanzaron quedan registradas como tales, no como éxito ni como fallo.
        val recorded = _ui.value.steps.map { it.phase }.toSet()
        val pendingOutcome = if (cancelRequested) StepOutcome.CANCELLED else StepOutcome.SKIPPED
        for (phase in WfdPhase.values()) {
            if (phase != WfdPhase.CLEANUP && phase !in recorded) {
                step(phase, pendingOutcome, "No se llegó a esta fase.")
            }
        }

        val m = manager
        val ch = channel
        var cleanupDetail = "Sockets cerrados."
        if (m != null && ch != null) {
            runCatching { m.stopPeerDiscovery(ch, null) }
            val closeChannel: () -> Unit = { if (Build.VERSION.SDK_INT >= 27) runCatching { ch.close() } }
            if (ownsGroup) {
                try {
                    m.removeGroup(ch, object : WifiP2pManager.ActionListener {
                        override fun onSuccess() {
                            log("Grupo Wi-Fi Direct de la prueba eliminado.")
                            closeChannel()
                        }

                        override fun onFailure(reason: Int) {
                            log("No se pudo confirmar la eliminación del grupo: ${P2pText.failure(reason)}.")
                            closeChannel()
                        }
                    })
                    cleanupDetail += " Se pidió eliminar el grupo creado por la prueba."
                } catch (e: SecurityException) {
                    closeChannel()
                }
            } else {
                runCatching { m.cancelConnect(ch, null) }
                closeChannel()
                cleanupDetail += " Solicitud pendiente cancelada."
            }
        }
        receiver?.let { runCatching { app.unregisterReceiver(it) } }
        receiver = null
        channel = null
        manager = null

        updateObs { it.copy(finished = true, cancelled = cancelRequested) }
        step(WfdPhase.CLEANUP, StepOutcome.OK, cleanupDetail)
        _ui.update { it.copy(running = false) }
    }

    // ---- Utilidades ----

    private fun elapsed(): Long = SystemClock.elapsedRealtime() - startedAt

    private fun updateObs(block: (WfdObservation) -> WfdObservation) {
        _ui.update { it.copy(observation = block(it.observation)) }
    }

    private fun step(phase: WfdPhase, outcome: StepOutcome, detail: String) {
        val s = WfdStep(phase, outcome, elapsed(), detail)
        _ui.update { it.copy(steps = it.steps + s) }
        log(WfdDiagnosticText.stepLine(s))
    }

    private fun log(text: String) {
        val line = String.format(java.util.Locale.US, "+%.1f s  %s", elapsed() / 1000.0, text)
        _ui.update { it.copy(log = (it.log + line).takeLast(120)) }
    }
}
